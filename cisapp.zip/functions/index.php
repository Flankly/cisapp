<?php
#Pagina de segurança, que remove usuários que entrem indevidamente pelo link, e os envia para o painel
header("Location: ../index.html");
?>